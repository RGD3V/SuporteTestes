
function clickMenu() {
    if (menu.style.display == `block`) {
        menu.style.display = `none`
    } else { menu.style.display = `block` }
}

function resize() { 
    if (window.innerWidth >= 768) {
        menu.style.display = `none`
    } else { menu.style.display = `block` }
}
        
        
        document.getElementById('copyTextAgudos').addEventListener('click', function() {
            copyToClipboard('R. Aparecida do Norte, 90 - Vila Honorina. CEP: 17120-000 https://goo.gl/maps/XpYpQcteLaLxLVoL9');
        });

        function copyToClipboard(text) {
            var textArea = document.createElement('textarea');
            textArea.value = text;

            // Adiciona o elemento ao corpo do documento
            document.body.appendChild(textArea);

            // Seleciona o conteúdo do textarea
            textArea.select();

            // Executa o comando de cópia
            document.execCommand('copy');

            // Remove o textarea do documento
            document.body.removeChild(textArea);

            // Pode exibir uma mensagem ou fazer outras ações após a cópia
            alert('ENDEREÇO COPIADO!');
        }


            document.getElementById('copyTextAraraquara').addEventListener('click', function() {
                copyToClipboard('Av. Dr. Waldomiro Blundi, 54. CEP: 14807-422 https://maps.app.goo.gl/VkzdRejp6KS4Uxaw8');
            });

            function copyToClipboard(text) {
                var textArea = document.createElement('textarea');
                textArea.value = text;

                // Adiciona o elemento ao corpo do documento
                document.body.appendChild(textArea);

                // Seleciona o conteúdo do textarea
                textArea.select();

                // Executa o comando de cópia
                document.execCommand('copy');

                // Remove o textarea do documento
                document.body.removeChild(textArea);

                // Pode exibir uma mensagem ou fazer outras ações após a cópia
                alert('ENDEREÇO COPIADO!');
            }
        

                document.getElementById('copyTextAvare').addEventListener('click', function() {
                    copyToClipboard('Sp 255 Km 264 Zona Rural , S/N - De frente com a INRODA https://maps.app.goo.gl/dhHBZNQUZw1tACz36');
                });

                function copyToClipboard(text) {
                    var textArea = document.createElement('textarea');
                    textArea.value = text;

                    // Adiciona o elemento ao corpo do documento
                    document.body.appendChild(textArea);

                    // Seleciona o conteúdo do textarea
                    textArea.select();

                    // Executa o comando de cópia
                    document.execCommand('copy');

                    // Remove o textarea do documento
                    document.body.removeChild(textArea);

                    // Pode exibir uma mensagem ou fazer outras ações após a cópia
                    alert('ENDEREÇO COPIADO!');
                }


                    document.getElementById('copyTextBarretos').addEventListener('click', function() {
                        copyToClipboard('Rua Altair Do Nascimento, 850. CEP: 14783-152 https://maps.app.goo.gl/cnC8Mk346ZVRAWZg8');
                    });

                    function copyToClipboard(text) {
                        var textArea = document.createElement('textarea');
                        textArea.value = text;

                        // Adiciona o elemento ao corpo do documento
                        document.body.appendChild(textArea);

                        // Seleciona o conteúdo do textarea
                        textArea.select();

                        // Executa o comando de cópia
                        document.execCommand('copy');

                        // Remove o textarea do documento
                        document.body.removeChild(textArea);

                        // Pode exibir uma mensagem ou fazer outras ações após a cópia
                        alert('ENDEREÇO COPIADO!');
                    }


                        document.getElementById('copyTextBotucatu').addEventListener('click', function() {
                            copyToClipboard('Avenida Das Hortências, 1703. CEP: 18065-258 https://maps.app.goo.gl/nCR5UbxJm1wWQ5He7');
                        });

                        function copyToClipboard(text) {
                            var textArea = document.createElement('textarea');
                            textArea.value = text;

                            // Adiciona o elemento ao corpo do documento
                            document.body.appendChild(textArea);

                            // Seleciona o conteúdo do textarea
                            textArea.select();

                            // Executa o comando de cópia
                            document.execCommand('copy');

                            // Remove o textarea do documento
                            document.body.removeChild(textArea);

                            // Pode exibir uma mensagem ou fazer outras ações após a cópia
                            alert('ENDEREÇO COPIADO!');
                        }

                            
                                document.getElementById('copyTextCaraguatatuba').addEventListener('click', function() {
                                    copyToClipboard('Rua Aríetes, 100. Próximo à policia rodoviária Tamoios https://maps.app.goo.gl/uJH3cYCjRFRAMU8E8');
                                });

                                function copyToClipboard(text) {
                                    var textArea = document.createElement('textarea');
                                    textArea.value = text;

                                    // Adiciona o elemento ao corpo do documento
                                    document.body.appendChild(textArea);

                                    // Seleciona o conteúdo do textarea
                                    textArea.select();

                                    // Executa o comando de cópia
                                    document.execCommand('copy');

                                    // Remove o textarea do documento
                                    document.body.removeChild(textArea);

                                    // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                    alert('ENDEREÇO COPIADO!');
                                }


                                    document.getElementById('copyTextCerqueira').addEventListener('click', function() {
                                        copyToClipboard('Avenida João Cardoso de Oliveira, 870 - Centro. https://goo.gl/maps/hoRjHjehcePnUsuJA');
                                    });
        
                                    function copyToClipboard(text) {
                                        var textArea = document.createElement('textarea');
                                        textArea.value = text;
        
                                        // Adiciona o elemento ao corpo do documento
                                        document.body.appendChild(textArea);
        
                                        // Seleciona o conteúdo do textarea
                                        textArea.select();
        
                                        // Executa o comando de cópia
                                        document.execCommand('copy');
        
                                        // Remove o textarea do documento
                                        document.body.removeChild(textArea);
        
                                        // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                        alert('ENDEREÇO COPIADO!');
                                    }


                                        document.getElementById('copyTextGuararapes').addEventListener('click', function() {
                                            copyToClipboard('Estrada Vicinal Natal Scatolin, S/N. Km 04 - Corrego Nascente. https://goo.gl/maps/uCSchwDjTZ5rFw3a9');
                                        });
            
                                        function copyToClipboard(text) {
                                            var textArea = document.createElement('textarea');
                                            textArea.value = text;
            
                                            // Adiciona o elemento ao corpo do documento
                                            document.body.appendChild(textArea);
            
                                            // Seleciona o conteúdo do textarea
                                            textArea.select();
            
                                            // Executa o comando de cópia
                                            document.execCommand('copy');
            
                                            // Remove o textarea do documento
                                            document.body.removeChild(textArea);
            
                                            // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                            alert('ENDEREÇO COPIADO!');
                                        }


                                            document.getElementById('copyTextJau').addEventListener('click', function() {
                                                copyToClipboard('Av. Lourenço Neto De Almeida Prado, 1031 - Atrás do Território do Calçado. https://maps.app.goo.gl/xEGFfAuAGbShf8En7');
                                            });
                
                                            function copyToClipboard(text) {
                                                var textArea = document.createElement('textarea');
                                                textArea.value = text;
                
                                                // Adiciona o elemento ao corpo do documento
                                                document.body.appendChild(textArea);
                
                                                // Seleciona o conteúdo do textarea
                                                textArea.select();
                
                                                // Executa o comando de cópia
                                                document.execCommand('copy');
                
                                                // Remove o textarea do documento
                                                document.body.removeChild(textArea);
                
                                                // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                alert('ENDEREÇO COPIADO!');
                                            }


                                                document.getElementById('copyTextMarilia').addEventListener('click', function() {
                                                    copyToClipboard('Rodovia Comandante João Ribeiro De Barros, Sp 294 - Km 464, S/N. https://maps.app.goo.gl/aZAuKhEth87MSuQt5');
                                                });
                    
                                                function copyToClipboard(text) {
                                                    var textArea = document.createElement('textarea');
                                                    textArea.value = text;
                    
                                                    // Adiciona o elemento ao corpo do documento
                                                    document.body.appendChild(textArea);
                    
                                                    // Seleciona o conteúdo do textarea
                                                    textArea.select();
                    
                                                    // Executa o comando de cópia
                                                    document.execCommand('copy');
                    
                                                    // Remove o textarea do documento
                                                    document.body.removeChild(textArea);
                    
                                                    // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                    alert('ENDEREÇO COPIADO!');
                                                }


                                                    document.getElementById('copyTextMirassol').addEventListener('click', function() {
                                                        copyToClipboard('Av. Airton José Bilachi, 3965 - Próximo ao laboratório de alimentos Intertek Brasil. https://goo.gl/maps/8ChdzQtKAxVAKsHm7');
                                                    });
                        
                                                    function copyToClipboard(text) {
                                                        var textArea = document.createElement('textarea');
                                                        textArea.value = text;
                        
                                                        // Adiciona o elemento ao corpo do documento
                                                        document.body.appendChild(textArea);
                        
                                                        // Seleciona o conteúdo do textarea
                                                        textArea.select();
                        
                                                        // Executa o comando de cópia
                                                        document.execCommand('copy');
                        
                                                        // Remove o textarea do documento
                                                        document.body.removeChild(textArea);
                        
                                                        // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                        alert('ENDEREÇO COPIADO!');
                                                    }


                                                            document.getElementById('copyTextOurinhos').addEventListener('click', function() {
                                                                copyToClipboard('Rua Mario de Oliveira Branco, 150 - Atras da Ouribram. https://goo.gl/maps/dzt6AecAoQnq99PW9');
                                                            });
                                
                                                            function copyToClipboard(text) {
                                                                var textArea = document.createElement('textarea');
                                                                textArea.value = text;
                                
                                                                // Adiciona o elemento ao corpo do documento
                                                                document.body.appendChild(textArea);
                                
                                                                // Seleciona o conteúdo do textarea
                                                                textArea.select();
                                
                                                                // Executa o comando de cópia
                                                                document.execCommand('copy');
                                
                                                                // Remove o textarea do documento
                                                                document.body.removeChild(textArea);
                                
                                                                // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                alert('ENDEREÇO COPIADO!');
                                                            }


                                                                document.getElementById('copyTextPrudente').addEventListener('click', function() {
                                                                    copyToClipboard('Rodovia Assis Chateaubriand Sp 425, Km 459 - Em frente ao águia da PM. https://goo.gl/maps/xtSSKJiV4do8pi1y8');
                                                                });
                                    
                                                                function copyToClipboard(text) {
                                                                    var textArea = document.createElement('textarea');
                                                                    textArea.value = text;
                                    
                                                                    // Adiciona o elemento ao corpo do documento
                                                                    document.body.appendChild(textArea);
                                    
                                                                    // Seleciona o conteúdo do textarea
                                                                    textArea.select();
                                    
                                                                    // Executa o comando de cópia
                                                                    document.execCommand('copy');
                                    
                                                                    // Remove o textarea do documento
                                                                    document.body.removeChild(textArea);
                                    
                                                                    // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                    alert('ENDEREÇO COPIADO!');
                                                                }


                                                                    document.getElementById('copyTextBolsao').addEventListener('click', function() {
                                                                        copyToClipboard('Rodovia Orlando Quagliato, Km 10 - Em frente ao motel Vila Verde. https://maps.app.goo.gl/8ZshLEF8oa1CTcNd8');
                                                                    });
                                        
                                                                    function copyToClipboard(text) {
                                                                        var textArea = document.createElement('textarea');
                                                                        textArea.value = text;
                                        
                                                                        // Adiciona o elemento ao corpo do documento
                                                                        document.body.appendChild(textArea);
                                        
                                                                        // Seleciona o conteúdo do textarea
                                                                        textArea.select();
                                        
                                                                        // Executa o comando de cópia
                                                                        document.execCommand('copy');
                                        
                                                                        // Remove o textarea do documento
                                                                        document.body.removeChild(textArea);
                                        
                                                                        // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                        alert('ENDEREÇO COPIADO!');
                                                                    }


                                                                        document.getElementById('copyTextSantana').addEventListener('click', function() {
                                                                            copyToClipboard('Rodovia Elzirio Martins Km 1/5, S/N. CENTRO. https://maps.app.goo.gl/9j89ZXf4Jc4iku6M6');
                                                                        });
                                            
                                                                        function copyToClipboard(text) {
                                                                            var textArea = document.createElement('textarea');
                                                                            textArea.value = text;
                                            
                                                                            // Adiciona o elemento ao corpo do documento
                                                                            document.body.appendChild(textArea);
                                            
                                                                            // Seleciona o conteúdo do textarea
                                                                            textArea.select();
                                            
                                                                            // Executa o comando de cópia
                                                                            document.execCommand('copy');
                                            
                                                                            // Remove o textarea do documento
                                                                            document.body.removeChild(textArea);
                                            
                                                                            // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                            alert('ENDEREÇO COPIADO!');
                                                                        }


                                                                            document.getElementById('copyTextRioPreto').addEventListener('click', function() {
                                                                                copyToClipboard('Rua Felipe Assad Karam, 300 - Estância Jockey Clube. https://maps.app.goo.gl/kXvp1iL2ae3Wkz9H8');
                                                                            });
                                                
                                                                            function copyToClipboard(text) {
                                                                                var textArea = document.createElement('textarea');
                                                                                textArea.value = text;
                                                
                                                                                // Adiciona o elemento ao corpo do documento
                                                                                document.body.appendChild(textArea);
                                                
                                                                                // Seleciona o conteúdo do textarea
                                                                                textArea.select();
                                                
                                                                                // Executa o comando de cópia
                                                                                document.execCommand('copy');
                                                
                                                                                // Remove o textarea do documento
                                                                                document.body.removeChild(textArea);
                                                
                                                                                // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                                alert('ENDEREÇO COPIADO!');
                                                                            }

                                                                            document.getElementById('copyTextSaoVicente').addEventListener('click', function() {
                                                                                copyToClipboard('Av. Martins Fontes nº1118. https://maps.app.goo.gl/DuG7De2nVsdbpAWdA');
                                                                            });
                                                
                                                                            function copyToClipboard(text) {
                                                                                var textArea = document.createElement('textarea');
                                                                                textArea.value = text;
                                                
                                                                                // Adiciona o elemento ao corpo do documento
                                                                                document.body.appendChild(textArea);
                                                
                                                                                // Seleciona o conteúdo do textarea
                                                                                textArea.select();
                                                
                                                                                // Executa o comando de cópia
                                                                                document.execCommand('copy');
                                                
                                                                                // Remove o textarea do documento
                                                                                document.body.removeChild(textArea);
                                                
                                                                                // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                                alert('ENDEREÇO COPIADO!');
                                                                            }


                                                                                document.getElementById('copyTextSorocaba').addEventListener('click', function() {
                                                                                    copyToClipboard('Estrada Ferroviário João De Oliveira, 100. Bairro Ipanema Das Pedras. https://goo.gl/maps/XBMws1WLEZjDGhvk8');
                                                                                });
                                                    
                                                                                function copyToClipboard(text) {
                                                                                    var textArea = document.createElement('textarea');
                                                                                    textArea.value = text;
                                                    
                                                                                    // Adiciona o elemento ao corpo do documento
                                                                                    document.body.appendChild(textArea);
                                                    
                                                                                    // Seleciona o conteúdo do textarea
                                                                                    textArea.select();
                                                    
                                                                                    // Executa o comando de cópia
                                                                                    document.execCommand('copy');
                                                    
                                                                                    // Remove o textarea do documento
                                                                                    document.body.removeChild(textArea);
                                                    
                                                                                    // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                                    alert('ENDEREÇO COPIADO!');
                                                                                }


                                                                                    document.getElementById('copyTextTremembe').addEventListener('click', function() {
                                                                                        copyToClipboard('Estrada Três Cruzes, 718 - Bairro Tremembé. https://maps.app.goo.gl/wGZUX5ZWRpzWNbJP8');
                                                                                    });
                                                        
                                                                                    function copyToClipboard(text) {
                                                                                        var textArea = document.createElement('textarea');
                                                                                        textArea.value = text;
                                                        
                                                                                        // Adiciona o elemento ao corpo do documento
                                                                                        document.body.appendChild(textArea);
                                                        
                                                                                        // Seleciona o conteúdo do textarea
                                                                                        textArea.select();
                                                        
                                                                                        // Executa o comando de cópia
                                                                                        document.execCommand('copy');
                                                        
                                                                                        // Remove o textarea do documento
                                                                                        document.body.removeChild(textArea);
                                                        
                                                                                        // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                                        alert('ENDEREÇO COPIADO!');
                                                                                    }


                                                                                        document.getElementById('copyTextTeodoro').addEventListener('click', function() {
                                                                                            copyToClipboard('Rodovia Arlindo Betio, km 01. - https://maps.app.goo.gl/sm2gX9q8dFbXJsbi6');
                                                                                        });
                                                            
                                                                                        function copyToClipboard(text) {
                                                                                            var textArea = document.createElement('textarea');
                                                                                            textArea.value = text;
                                                            
                                                                                            // Adiciona o elemento ao corpo do documento
                                                                                            document.body.appendChild(textArea);
                                                            
                                                                                            // Seleciona o conteúdo do textarea
                                                                                            textArea.select();
                                                            
                                                                                            // Executa o comando de cópia
                                                                                            document.execCommand('copy');
                                                            
                                                                                            // Remove o textarea do documento
                                                                                            document.body.removeChild(textArea);
                                                            
                                                                                            // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                                            alert('ENDEREÇO COPIADO!');
                                                                                        }


                                                                                            document.getElementById('copyTextUbatuba').addEventListener('click', function() {
                                                                                                copyToClipboard('Estrada Monte Valério, 2300 - 300 mt após o campo de futebol. https://maps.app.goo.gl/Ug8SUDpuTon6SRzQ8');
                                                                                            });
                                                                
                                                                                            function copyToClipboard(text) {
                                                                                                var textArea = document.createElement('textarea');
                                                                                                textArea.value = text;
                                                                
                                                                                                // Adiciona o elemento ao corpo do documento
                                                                                                document.body.appendChild(textArea);
                                                                
                                                                                                // Seleciona o conteúdo do textarea
                                                                                                textArea.select();
                                                                
                                                                                                // Executa o comando de cópia
                                                                                                document.execCommand('copy');
                                                                
                                                                                                // Remove o textarea do documento
                                                                                                document.body.removeChild(textArea);
                                                                
                                                                                                // Pode exibir uma mensagem ou fazer outras ações após a cópia
                                                                                                alert('ENDEREÇO COPIADO!');
                                                                                            }